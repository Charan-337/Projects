<html>
<head>
 <link rel="stylesheet" href="css/indexstyle.css">
 <title>Social Networking site</title>

</head>

<div id="navwrapper">
  
    
      
    
    <h1 class="logowrapper">Social Networking site</h1>
   
  </div>
  </div>

  <div id="contentwrapper">
    <div id="content">
      
      <div id="leftbod">
        
        <div class="connect bolder">
          A website designed by SRM students to interact with your friends</div>
        
        <div class="leftbar">
          <img src="image/a.png" alt="" class="iconwrap fb1"/>
          <div class="fb1">
            <span class="rowtext">Share your views,photos</span>
            <span class="rowtext2 fb1">and connect with your friends</span>
            <div class="button">
            
            <p>Already have an account?</p>
            <li><a href="signin.php" title="Sign in"><button class="btn-sign-in" value="Sign in">Sign in</button></a></li>
            <p>New to the site?Sign up Here!</p>	      
<li><a href="signup.php" title="Sign up"><button class="btn-sign-up" value="Sign up">Sign up</button></a></li>
          </div>
          </div>
        </div> 
          
          
       
            
      </div>
       
      
          
      </div>
     </div>
    </div>
 </html>
  