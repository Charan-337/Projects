<?php
$con = mysqli_connect('localhost','root','','Social_Network');
?>
